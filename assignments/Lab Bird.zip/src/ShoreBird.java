/**
 * ShoreBird Class
 */
public class ShoreBird extends WaterBird {
    public ShoreBird(BirdType birdType) {
        super(birdType);
    }

    public ShoreBird(String name, BirdType birdtype) {
        super(name, birdtype);
    }
}
