/**
 * Define a type of Food for the form of food that the birds prefer to eat from
 */
public enum Food {
    berries, seeds, fruit, insects, otherBirds, eggs, smallMammals, fish, buds, larvae, aquaticInvertebrates, nuts, vegetation
}
