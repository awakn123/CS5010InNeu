import static org.junit.Assert.*;

public class BookTest {

    @org.junit.Test
    public void getTitle() {
    }

    @org.junit.Test
    public void getPrice() {
    }

    @org.junit.Test
    public void getAuthor() {
    }
}